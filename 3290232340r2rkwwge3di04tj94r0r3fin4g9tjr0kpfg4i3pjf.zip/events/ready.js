module.exports = bot => {
    console.log('Bot is online!')
}