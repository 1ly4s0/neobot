module.exports = class Eventos {
  constructor(name) {
    this.name = name;
  }
}